package org.example;

public enum Naipe {
    HEARTS,     // Copas
    DIAMONDS,   // Ouros
    CLUBS,      // paus
    SPADES      // espadas
}
