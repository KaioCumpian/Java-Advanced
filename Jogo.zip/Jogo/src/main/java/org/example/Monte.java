package org.example;

public class Monte {

}
